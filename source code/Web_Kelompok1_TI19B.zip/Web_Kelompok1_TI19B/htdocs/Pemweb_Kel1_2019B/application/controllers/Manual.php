<?php

class Manual extends CI_Controller {
	public function index()
	{
		$data['judul'] = 'Halaman Manual Book';
		$this->load->view('templates/header', $data);
		$this->load->view('manual/index');
		$this->load->view('templates/footer');
		$this->load->helper('download');
		$data = file_get_contents(base_url().'assets/pdf/manual.pdf');
		$name = "Manual_Book.pdf";

		force_download($name, $data);
	}
}
