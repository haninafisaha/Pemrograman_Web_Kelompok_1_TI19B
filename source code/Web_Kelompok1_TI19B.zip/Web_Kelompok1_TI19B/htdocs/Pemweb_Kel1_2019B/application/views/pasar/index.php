<div class="container" style="padding-top: 15px;">
        <div class="card-group">
            <div class="card">
            <img src="<?php echo base_url() ?>assets/images/kultur.jpg" class="card-img-top" alt="gambar1">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
              </div>
            </div>
            <div class="card">
              <img src="<?php echo base_url() ?>assets/images/pertanian2.jpg" class="card-img-top" alt="gambar2">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
              </div>
            </div>
            <div class="card">
            	<img src="<?php echo base_url() ?>assets/images/pertanian3.jpg" class="card-img-top" alt="gambar3">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
              </div>
            </div>
        </div>
          </div>
          
<!-- blog -->
<div class="container" style="padding-top: 15px;">
  <div class="row">
    <div class="col-sm-8">
      <!-- <div class="row row-cols-1 row-cols-md-3 g-4" > -->
      <div class="col">
        <div class="card h-100">
          <img src="<?php echo base_url() ?>assets/images/pertanian4.jpg" class="card-img-top" alt="gambar4">
          <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card h-100">
          <img src="<?php echo base_url() ?>assets/images/pertanian5.jpg" class="card-img-top" alt="gambar5">
          <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">This is a short card.</p>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card h-100">
          <img src="<?php echo base_url() ?>assets/images/pertanian6.jpg" class="card-img-top" alt="gambar6">
          <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content.</p>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card h-100">
          <img src="<?php echo base_url() ?>assets/images/petani.jpg" class="card-img-top" alt="gambar7">
          <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
        </div>
      <!-- </div> -->
    </div>
  </div>

    <!-- col -->
    <div class="col-sm-4">
      <div class="card" style="width: 100%;">
        <div class="card-body">
          <h5 class="card-title">Special title treatment</h5>
          <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
          <a href="#" class="btn btn-primary">Go somewhere</a>
        </div>
      </div>
      
      <div class="card text-center" style="width: 100%;">
        <div class="card-body">
          <h5 class="card-title">Special title treatment</h5>
          <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
          <a href="#" class="btn btn-primary">Go somewhere</a>
        </div>
      </div>
      
      <div class="card text-end" style="width: 100%;">
        <div class="card-body">
          <h5 class="card-title">Special title treatment</h5>
          <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
          <a href="#" class="btn btn-primary">Go somewhere</a>
        </div>
      </div>

      <!-- <div class="row row-cols-1 row-cols-md-3 g-4"> -->
        <div class="col">
          <div class="card">
            <img src="<?php echo base_url() ?>assets/images/pertanian7.jpg" class="card-img-top" alt="gambar8">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card">
            <img src="<?php echo base_url() ?>assets/images/pertanian8.jpg" class="card-img-top" alt="gambar9">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card">
            <img src="<?php echo base_url() ?>assets/images/apel.jpg" class="card-img-top" alt="gambar10">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content.</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card">
            <img src="<?php echo base_url() ?>assets/images/jeruk.jpg" class="card-img-top" alt="gambar11">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
            </div>
          </div>
        <!-- </div> -->
      </div>
    </div>
  </div>
  </div>