<div class="container">
	<div class="row mt-1">
		<div class="col-md-6">
			<a href="<?= base_url(); ?>mahasiswa/tambah" class="btn btn-primary">Tambahkan Data TO-DO List</a>
		</div>
	</div>
	<?php if( $this->session->flashdata('flash')) : ?>
	<div class="row mt-3">
		<div class="col-md-6">
			<div class="alert alert-success alert-dismissible fade show" role="alert">
				Data TO-DO List <strong>berhasil</strong> <?= $this->session->flashdata('flash'); ?>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true>&times;"></span>
				</button>
			</div>
		</div>
	<?php endif; ?>


	<div class="row mt-3">
		<div class="col-md-6">
			<h3>Daftar Submitted TO-DO List</h3>
		<ul class="list-group">
			<?php foreach( $mahasiswa as $mhs) : ?>
				<li class="list-group-item"><?= $mhs['hari']; ?>, <?= $mhs['tanggal']; ?> pukul <?= $mhs['jam']; ?>
					<a href="<?= base_url(); ?>mahasiswa/hapus/<?= $mhs['id']; ?>" class="badge badge-danger float-right" onclick="return confirm('Apakah anda yakin untuk menghapus data ini?');">hapus</a>
					<a href="<?= base_url(); ?>mahasiswa/ubah/<?= $mhs['id']; ?>" class="badge badge-success float-right">ubah</a>
					<a href="<?= base_url(); ?>mahasiswa/detail/<?= $mhs['id']; ?>" class="badge badge-primary float-right">detail</a>
				</li>
			<?php endforeach?>
		</ul>
		</div>
	</div>
</div>