<div class="container" style="padding-top: 15px;">
        <div class="row row-cols-1 row-cols-md-3 g-4">
            <div class="col">
              <div class="card h-100">
              	<img src="<?php echo base_url() ?>assets/images/tanaman2.png" class="card-img-top" alt="gambar1">
                <div class="card-body">
                  <h5 class="card-title">Card title</h5>
                  <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card h-100">
              	<img src="<?php echo base_url() ?>assets/images/mengangkut2.jpg" class="card-img-top" alt="gambar2">
                <div class="card-body">
                  <h5 class="card-title">Card title</h5>
                  <p class="card-text">This is a short card.</p>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card h-100">
              	<img src="<?php echo base_url() ?>assets/images/menanam2.jpg" class="card-img-top" alt="gambar3">
                <div class="card-body">
                  <h5 class="card-title">Card title</h5>
                  <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content.</p>
                </div>
              </div>
            </div>
            <div class="col">
                <div class="card h-100">
                  <img src="<?php echo base_url() ?>assets/images/cari2.jpg" class="card-img-top" alt="gambar4">
                  <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content.</p>
                  </div>
                </div>
              </div>
              <div class="col">
                <div class="card h-100">
                  <img src="<?php echo base_url() ?>assets/images/liputan2.jpg" class="card-img-top" alt="gambar5">
                  <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content.</p>
                  </div>
                </div>
              </div>
            <div class="col">
              <div class="card h-100">
              	<img src="<?php echo base_url() ?>assets/images/petani2.jpg" class="card-img-top" alt="gambar6">
                <div class="card-body">
                  <h5 class="card-title">Card title</h5>
                  <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                </div>
              </div>
            </div>
          </div>
      </div>